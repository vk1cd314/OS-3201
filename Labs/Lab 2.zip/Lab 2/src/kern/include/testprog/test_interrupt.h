#ifndef __TEST_INTERRUPT_H
#define __TEST_INTERRUPT_H

void test_hardfault(void);

#endif